import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Mission } from '../mission';

//import { map } from 'rxjs/operators';
import { DateService} from '../date.service'
import { ConditionalExpr } from '@angular/compiler';


@Component({
  selector: 'app-missionlist',
  templateUrl: './missionlist.component.html',
  styleUrls: ['./missionlist.component.css']
})
export class MissionlistComponent implements OnInit {
  private REST_API_END_POINT = "https://api.spacexdata.com/v3/launches"

  missions:Mission[] = []
  selectedMission?: Mission;
  
  today:Date = new Date();
  
  constructor(private httpClient: HttpClient, /*private dateService:DateService*/) {
   }

  ngOnInit(): void {
    this.httpClient.get(this.REST_API_END_POINT)
    .subscribe((response: any) => {
      console.log(response)
      this.missions = response
    })
    //this.today = this.dateService.seeDate()
  }
  onSelect(mission: Mission): void {
    this.selectedMission = mission;
  }
  
  
}
