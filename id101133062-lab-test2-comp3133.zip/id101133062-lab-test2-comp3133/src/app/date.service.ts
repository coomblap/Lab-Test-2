import { Injectable } from '@angular/core';
import { Mission } from './mission';
import { DatePipe } from '@angular/common';

@Injectable({
  providedIn: 'root'
})
export class DateService {
  reportDate: Date = new Date();
  line = '';
  constructor(private datePipe: DatePipe) {
   }
 
  seeDate() {
    this.line = `${this.datePipe.transform(this.reportDate, 'short')}`;
   }
}
